# ------------------------------------------------------------------------------
# 1. Install and load libraries
# ------------------------------------------------------------------------------


if (!requireNamespace("keras", quietly = TRUE)) install.packages("keras")
if (!requireNamespace("tensorflow", quietly = TRUE)) install.packages("tensorflow")

library(keras)
library(tensorflow)

# ------------------------------------------------------------------------------
# 2. Install Keras and TensorFlow if not already installed
# ------------------------------------------------------------------------------
if (!keras::is_keras_available()) {
    keras::install_keras()
}

# ------------------------------------------------------------------------------
# 3. Loading Fashion MNIST dataset
# ------------------------------------------------------------------------------
fashion_mnist <- dataset_fashion_mnist()

# Split into training and test sets
train_images <- fashion_mnist$train$x
train_labels <- fashion_mnist$train$y
test_images <- fashion_mnist$test$x
test_labels <- fashion_mnist$test$y

# ------------------------------------------------------------------------------
# 4. Preprocessing the data
# ------------------------------------------------------------------------------
# Normalize pixel values to [0,1]
train_images <- train_images / 255
test_images <- test_images / 255

# Reshape for convolutional layers
train_images <- array_reshape(train_images, c(dim(train_images)[1], 28, 28, 1))
test_images <- array_reshape(test_images, c(dim(test_images)[1], 28, 28, 1))

# Convert class vectors to one-hot encoded
train_labels <- to_categorical(train_labels, 10)
test_labels <- to_categorical(test_labels, 10)

# ------------------------------------------------------------------------------
# 5. Build the Convolutional Neural Network Model
# ------------------------------------------------------------------------------
model <- keras_model_sequential() %>%
    layer_conv_2d(filters = 32, kernel_size = c(3, 3), activation = "relu", input_shape = c(28, 28, 1)) %>%
    layer_max_pooling_2d(pool_size = c(2, 2)) %>%
    layer_conv_2d(filters = 64, kernel_size = c(3, 3), activation = "relu") %>%
    layer_max_pooling_2d(pool_size = c(2, 2)) %>%
    layer_flatten() %>%
    layer_dense(units = 128, activation = "relu") %>%
    layer_dense(units = 10, activation = "softmax")

# ------------------------------------------------------------------------------
# 6. Compile the Model
# ------------------------------------------------------------------------------
model %>% compile(
    optimizer = optimizer_adam(), 
    loss = "categorical_crossentropy", 
    metrics = c("accuracy")
)

# ------------------------------------------------------------------------------
# 7. Train the Model
# ------------------------------------------------------------------------------
history <- model %>% fit(
    train_images, train_labels,
    epochs = 5,
    batch_size = 64,
    validation_split = 0.2
)

# ------------------------------------------------------------------------------
# 8. Evaluate the Model
# ------------------------------------------------------------------------------
score <- model %>% evaluate(test_images, test_labels, verbose = 0)
cat(sprintf("Test accuracy: %.2f%%\n", score[[2]] * 100))

# ------------------------------------------------------------------------------
# 9. Make Predictions
# ------------------------------------------------------------------------------
predictions <- model %>% predict(test_images)
predicted_classes <- apply(predictions, 1, which.max) - 1

cat("First 10 predicted classes:\n")
print(predicted_classes[1:10])

# ------------------------------------------------------------------------------
# 10. Save the Model
# ------------------------------------------------------------------------------
save_model_hdf5(model, "fashion_mnist_cnn.h5")

# ------------------------------------------------------------------------------
# 11. Reload the Model (Optionally)
# ------------------------------------------------------------------------------
loaded_model <- load_model_hdf5("fashion_mnist_cnn.h5")
loaded_score <- loaded_model %>% evaluate(test_images, test_labels, verbose = 0)
cat(sprintf("Loaded model test accuracy: %.2f%%\n", loaded_score[[2]] * 100))
